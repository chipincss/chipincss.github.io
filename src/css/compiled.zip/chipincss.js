// Site config
var siteTitle = 'shaunhoffer'
var siteURL = 'shaunhoffer.codehs.me'
var datenow = new Date()

function errorhand(message) {
    console.error(`ERROR: ${message}`)
    alert(`ERROR: ${message}`)
}


window.addEventListener('load', function() {
    const colorMode = window.matchMedia("(prefers-color-scheme: dark)").matches ? "color-dark" :"";
    var updateTheme = document.querySelector("body").setAttribute("class", colorMode)
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', updateTheme)
})

window.addEventListener('load', function() {
    document.querySelector('.opennav').addEventListener('click', function(e) {
        if (document.querySelector('.navbar ul').getAttribute('class')) {
            document.querySelector('.navbar ul').removeAttribute('class')
        } else  {
            document.querySelector('.navbar ul').setAttribute('class', 'open')
        }
        e.preventDefault()
    })
})